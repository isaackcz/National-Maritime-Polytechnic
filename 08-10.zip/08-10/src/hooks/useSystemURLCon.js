const useSystemURLCon = () => {
    const url = "http://5.5.55.202:8000/api";
    const urlWithoutToken = "http://5.5.55.202:8000";
    
    return { url, urlWithoutToken };
}

export default useSystemURLCon;